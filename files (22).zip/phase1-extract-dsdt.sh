#!/bin/bash
# V100 DSDT Patch - Phase 1: Extract and Prepare
# Run this on Proxmox WITHOUT the V100 installed

set -e

echo "=============================================="
echo "V100 DSDT Patching - Phase 1"
echo "Gigabyte GA-X99-UD4P + Tesla V100"
echo "=============================================="

# Create working directory
WORKDIR="/root/dsdt-patch"
mkdir -p $WORKDIR
cd $WORKDIR

echo "[1/6] Installing required tools..."
apt update
apt install -y acpica-tools pciutils

echo "[2/6] Extracting current DSDT..."
cat /sys/firmware/acpi/tables/DSDT > DSDT.aml
cp DSDT.aml DSDT.aml.original

echo "[3/6] Decompiling DSDT..."
iasl -d DSDT.aml 2>/dev/null || true

if [ ! -f DSDT.dsl ]; then
    echo "ERROR: Failed to decompile DSDT"
    exit 1
fi

echo "[4/6] Analyzing DSDT structure..."
echo ""
echo "=== QWordMemory entries ==="
grep -n "QWordMemory" DSDT.dsl || echo "None found"

echo ""
echo "=== DWordMemory entries ==="
grep -n "DWordMemory" DSDT.dsl | tail -5

echo ""
echo "=== Memory variables (M1LN, M2LN, etc) ==="
grep -n "M1LN\|M2LN\|M1MN\|M2MN\|M1MX\|M2MX" DSDT.dsl | head -20

echo ""
echo "=== TUUD references ==="
grep -n "TUUD" DSDT.dsl | head -5

echo "[5/6] Checking current PCI resources..."
echo ""
echo "=== Root bus resources ==="
dmesg | grep "root bus resource" || echo "Not found in dmesg"

echo ""
echo "=== Current PCI devices ==="
lspci | head -20

echo "[6/6] Creating backup..."
cp DSDT.dsl DSDT.dsl.backup

echo ""
echo "=============================================="
echo "Phase 1 Complete!"
echo "=============================================="
echo ""
echo "Files created in $WORKDIR:"
ls -la $WORKDIR
echo ""
echo "Next steps:"
echo "1. Review DSDT.dsl to understand structure"
echo "2. Run phase2-modify-dsdt.sh to apply patches"
echo "3. Run phase3-install-grub.sh to configure bootloader"
echo ""
