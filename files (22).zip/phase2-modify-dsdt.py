#!/usr/bin/env python3
"""
V100 DSDT Patch - Phase 2: Modify DSDT
Automatically patches DSDT.dsl to expose 64-bit memory region for Tesla V100

For: Gigabyte GA-X99-UD4P + Tesla V100 16GB
"""

import re
import sys
import os
from pathlib import Path

WORKDIR = Path("/root/dsdt-patch")

def find_last_dwordmemory(content):
    """Find the line number after the last DWordMemory block"""
    lines = content.split('\n')
    last_dword_end = -1
    in_dword = False
    paren_depth = 0
    
    for i, line in enumerate(lines):
        if 'DWordMemory' in line and 'ResourceProducer' in line:
            in_dword = True
            paren_depth = line.count('(') - line.count(')')
        elif in_dword:
            paren_depth += line.count('(') - line.count(')')
            if paren_depth <= 0:
                last_dword_end = i
                in_dword = False
    
    return last_dword_end

def find_m1ln_section(content):
    """Find where M1LN is created and used"""
    lines = content.split('\n')
    m1ln_line = -1
    
    for i, line in enumerate(lines):
        if 'CreateDWordField' in line and 'M1LN' in line:
            m1ln_line = i
        elif 'CreateQWordField' in line and 'M1LN' in line:
            m1ln_line = i
    
    # Find the end of the M1LN usage block (look for next major statement or Return)
    if m1ln_line > 0:
        for i in range(m1ln_line + 1, min(m1ln_line + 20, len(lines))):
            if 'Return' in lines[i] or 'CreateDWordField' in lines[i]:
                return m1ln_line, i
    
    return m1ln_line, m1ln_line + 5

def find_unique_label(content):
    """Find a unique label for our QWordMemory entry"""
    # Check what labels are already used
    used = set(re.findall(r'_Y([0-9A-F]{2})', content))
    
    # Find unused label starting from AF
    for i in range(0xAF, 0xFF):
        label = f'{i:02X}'
        if label not in used:
            return f'_Y{label}'
    
    return '_YAF'

def get_indent(line):
    """Get the indentation of a line"""
    return len(line) - len(line.lstrip())

def patch_dsdt(input_file, output_file):
    """Main patching function"""
    
    print(f"Reading {input_file}...")
    with open(input_file, 'r') as f:
        content = f.read()
    
    lines = content.split('\n')
    
    # Find unique label
    label = find_unique_label(content)
    print(f"Using label: {label}")
    
    # Find where to insert QWordMemory
    last_dword = find_last_dwordmemory(content)
    if last_dword < 0:
        print("ERROR: Could not find DWordMemory entries")
        return False
    
    print(f"Last DWordMemory ends at line {last_dword + 1}")
    
    # Get indentation from existing DWordMemory
    indent = ""
    for i in range(last_dword, max(0, last_dword - 10), -1):
        if 'DWordMemory' in lines[i]:
            indent = ' ' * get_indent(lines[i])
            break
    
    if not indent:
        indent = "                            "  # Default 28 spaces
    
    # QWordMemory block to insert
    qword_block = f'''
{indent}QWordMemory (ResourceProducer, PosDecode, MinFixed, MaxFixed, Cacheable, ReadWrite,
{indent}    0x0000000000000000, // Granularity
{indent}    0x0000000000010000, // Range Minimum
{indent}    0x000000000001FFFF, // Range Maximum
{indent}    0x0000000000000000, // Translation Offset
{indent}    0x0000000000010000, // Length
{indent}    ,, {label}, AddressRangeMemory, TypeStatic)'''
    
    # Insert QWordMemory after last DWordMemory
    lines.insert(last_dword + 1, qword_block)
    
    # Find M1LN section
    content = '\n'.join(lines)
    m1ln_start, m1ln_end = find_m1ln_section(content)
    
    if m1ln_start < 0:
        print("WARNING: Could not find M1LN section, searching for alternative...")
        # Try to find any CreateDWordField with _LEN
        for i, line in enumerate(lines):
            if 'CreateDWordField' in line and '_LEN' in line and 'M1' not in line:
                m1ln_start = i
                m1ln_end = i + 5
                break
    
    if m1ln_start < 0:
        print("ERROR: Could not find where to insert M2 variables")
        print("You may need to manually edit the DSDT")
        # Still save what we have
        with open(output_file, 'w') as f:
            f.write('\n'.join(lines))
        return False
    
    print(f"Found M1LN section around line {m1ln_start + 1}")
    
    # Get the PCI path from existing code
    pci_path = r"\_SB.PCI0"
    for line in lines[m1ln_start:m1ln_start+5]:
        match = re.search(r'(\\_SB\.PCI0\.[^.]+)', line)
        if match:
            # Extract just the base path
            pci_path = r"\_SB.PCI0"
            break
    
    # M2 variables block to insert
    m2_block = f'''
            CreateQWordField (BUF0, {pci_path}.{label}._LEN, M2LN)  // _LEN: Length
            CreateQWordField (BUF0, {pci_path}.{label}._MIN, M2MN)  // _MIN: Minimum Base Address
            CreateQWordField (BUF0, {pci_path}.{label}._MAX, M2MX)  // _MAX: Maximum Base Address

            // 46-bit addressing for X99/Haswell-E (64TB max)
            // This exposes 64-bit memory region for Tesla V100 16GB BAR
            M2MX = 0x3FFFFFFFFFFF - One
            If ((TUUD >= 0x1000))
            {{
                M2MN = (TUUD << 0x14)
            }}
            Else
            {{
                M2MN = 0x100000000
            }}

            M2LN = ((M2MX - M2MN) + One)
'''
    
    # Check if TUUD exists
    if 'TUUD' not in content:
        print("WARNING: TUUD not found in DSDT")
        print("Using simplified M2 block without TUUD check...")
        m2_block = f'''
            CreateQWordField (BUF0, {pci_path}.{label}._LEN, M2LN)  // _LEN: Length
            CreateQWordField (BUF0, {pci_path}.{label}._MIN, M2MN)  // _MIN: Minimum Base Address
            CreateQWordField (BUF0, {pci_path}.{label}._MAX, M2MX)  // _MAX: Maximum Base Address

            // 46-bit addressing for X99/Haswell-E (64TB max)
            // This exposes 64-bit memory region for Tesla V100 16GB BAR
            M2MN = 0x100000000
            M2MX = 0x3FFFFFFFFFFF - One
            M2LN = ((M2MX - M2MN) + One)
'''
    
    # Insert M2 block after M1LN section
    lines = '\n'.join(lines).split('\n')  # Refresh lines after previous insert
    
    # Re-find m1ln_end since we inserted content
    for i, line in enumerate(lines):
        if 'M1LN' in line and '=' in line and 'Create' not in line:
            m1ln_end = i + 1
            break
    
    lines.insert(m1ln_end, m2_block)
    
    # Write output
    print(f"Writing {output_file}...")
    with open(output_file, 'w') as f:
        f.write('\n'.join(lines))
    
    print("Patch complete!")
    return True

def compile_dsdt(dsl_file, aml_file):
    """Compile the modified DSDT"""
    import subprocess
    
    print(f"Compiling {dsl_file}...")
    result = subprocess.run(
        ['iasl', '-tc', dsl_file],
        capture_output=True,
        text=True
    )
    
    if result.returncode != 0:
        print("Compilation warnings/errors:")
        print(result.stderr)
        
    # Check if AML was created
    expected_aml = dsl_file.replace('.dsl', '.aml')
    if os.path.exists(expected_aml):
        if expected_aml != aml_file:
            os.rename(expected_aml, aml_file)
        print(f"Created {aml_file}")
        return True
    
    print("ERROR: Compilation failed to produce AML file")
    return False

def main():
    input_dsl = WORKDIR / "DSDT.dsl"
    output_dsl = WORKDIR / "DSDT_modified.dsl"
    output_aml = WORKDIR / "DSDT_modified.aml"
    
    if not input_dsl.exists():
        print(f"ERROR: {input_dsl} not found")
        print("Run phase1-extract-dsdt.sh first")
        sys.exit(1)
    
    print("=" * 50)
    print("V100 DSDT Patcher - Phase 2")
    print("=" * 50)
    print()
    
    # Patch the DSDT
    if not patch_dsdt(str(input_dsl), str(output_dsl)):
        print()
        print("Patching had issues. Please review the output file manually.")
    
    print()
    
    # Compile
    if compile_dsdt(str(output_dsl), str(output_aml)):
        print()
        print("=" * 50)
        print("Phase 2 Complete!")
        print("=" * 50)
        print()
        print(f"Modified DSL: {output_dsl}")
        print(f"Compiled AML: {output_aml}")
        print()
        print("Next: Run phase3-install-grub.sh")
    else:
        print()
        print("Compilation failed. Check errors above and fix manually.")
        print(f"Edit {output_dsl} to fix any issues, then run:")
        print(f"  iasl -tc {output_dsl}")

if __name__ == "__main__":
    main()
