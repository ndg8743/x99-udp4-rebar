#!/bin/bash
# V100 DSDT Patch - Phase 3: Configure GRUB
# Installs modified DSDT and sets kernel parameters

set -e

WORKDIR="/root/dsdt-patch"
DSDT_AML="$WORKDIR/DSDT_modified.aml"

echo "=============================================="
echo "V100 DSDT Patching - Phase 3"
echo "Configure GRUB Bootloader"
echo "=============================================="

# Check if modified DSDT exists
if [ ! -f "$DSDT_AML" ]; then
    echo "ERROR: $DSDT_AML not found"
    echo "Run phase2-modify-dsdt.py first"
    exit 1
fi

echo "[1/5] Installing modified DSDT to /boot..."
cp "$DSDT_AML" /boot/DSDT.aml
chmod 644 /boot/DSDT.aml
ls -la /boot/DSDT.aml

echo "[2/5] Creating GRUB ACPI loader..."
cat > /etc/grub.d/01_acpi << 'GRUBEOF'
#! /bin/sh
set -e

# Load custom DSDT for V100 support
if [ -f /boot/DSDT.aml ]; then
    echo "Loading custom DSDT from /boot/DSDT.aml" >&2
    prepare_grub_to_access_device `${grub_probe} --target=device /boot/DSDT.aml` 2>/dev/null || true
    cat << EOF
acpi /boot/DSDT.aml
EOF
fi
GRUBEOF

chmod +x /etc/grub.d/01_acpi
echo "Created /etc/grub.d/01_acpi"

echo "[3/5] Configuring kernel parameters..."
# Backup current grub config
cp /etc/default/grub /etc/default/grub.backup

# Check current GRUB_CMDLINE_LINUX_DEFAULT
CURRENT=$(grep "^GRUB_CMDLINE_LINUX_DEFAULT" /etc/default/grub || echo "")
echo "Current: $CURRENT"

# Parameters needed for V100
NEEDED_PARAMS="pci=realloc pci=nocrs pci=assign-busses"

# Add parameters if not present
if grep -q "GRUB_CMDLINE_LINUX_DEFAULT" /etc/default/grub; then
    # Extract current value
    CURRENT_VAL=$(grep "^GRUB_CMDLINE_LINUX_DEFAULT" /etc/default/grub | sed 's/.*="\(.*\)"/\1/')
    
    # Add our parameters if not already there
    NEW_VAL="$CURRENT_VAL"
    for param in $NEEDED_PARAMS; do
        if ! echo "$NEW_VAL" | grep -q "$param"; then
            NEW_VAL="$NEW_VAL $param"
        fi
    done
    
    # Update the file
    sed -i "s|^GRUB_CMDLINE_LINUX_DEFAULT=.*|GRUB_CMDLINE_LINUX_DEFAULT=\"$NEW_VAL\"|" /etc/default/grub
else
    # Add new line
    echo "GRUB_CMDLINE_LINUX_DEFAULT=\"quiet $NEEDED_PARAMS\"" >> /etc/default/grub
fi

echo "Updated kernel parameters:"
grep "^GRUB_CMDLINE_LINUX_DEFAULT" /etc/default/grub

echo "[4/5] Regenerating GRUB configuration..."
update-grub

echo "[5/5] Verifying GRUB configuration..."
echo ""
echo "=== DSDT in GRUB config ==="
grep -i "acpi\|dsdt" /boot/grub/grub.cfg | head -5 || echo "Not found (may be OK)"

echo ""
echo "=== Kernel parameters in GRUB config ==="
grep "pci=realloc" /boot/grub/grub.cfg | head -2 || echo "WARNING: pci=realloc not found"

echo ""
echo "=============================================="
echo "Phase 3 Complete!"
echo "=============================================="
echo ""
echo "Configuration summary:"
echo "  - DSDT: /boot/DSDT.aml"
echo "  - GRUB loader: /etc/grub.d/01_acpi"
echo "  - Kernel params: pci=realloc pci=nocrs pci=assign-busses"
echo ""
echo "=============================================="
echo "NEXT STEPS - HARDWARE INSTALLATION"
echo "=============================================="
echo ""
echo "1. Shutdown the system:"
echo "   shutdown -h now"
echo ""
echo "2. Install hardware:"
echo "   - Install GT 710 (or similar) for display output"
echo "   - Install Tesla V100 in PCIe x16 slot"
echo "   - Connect monitor to GT 710"
echo "   - Ensure power connections are secure"
echo ""
echo "3. Power on and watch for POST"
echo ""
echo "4. If system boots, run phase4-verify.sh to check V100"
echo ""
echo "=============================================="
echo "ROLLBACK (if needed)"
echo "=============================================="
echo ""
echo "If V100 won't POST, boot without it and run:"
echo "  rm /boot/DSDT.aml"
echo "  rm /etc/grub.d/01_acpi"
echo "  cp /etc/default/grub.backup /etc/default/grub"
echo "  update-grub"
echo ""
