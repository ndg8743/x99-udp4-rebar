#!/bin/bash
# V100 DSDT Patch - Phase 4: Verify V100 Working
# Run this after successfully booting with V100 installed

echo "=============================================="
echo "V100 DSDT Patching - Phase 4"
echo "Verification"
echo "=============================================="

echo "[1/8] Checking kernel command line..."
cat /proc/cmdline
echo ""

echo "[2/8] Checking if custom DSDT was loaded..."
dmesg | grep -i "ACPI: DSDT" || echo "DSDT info not found"
echo ""

echo "[3/8] Checking PCI root bus resources..."
echo "Looking for 64-bit memory region..."
dmesg | grep "root bus resource"
echo ""

echo "[4/8] Detecting NVIDIA devices..."
lspci | grep -i nvidia
echo ""

echo "[5/8] Checking V100 memory regions..."
V100_BUS=$(lspci | grep -i "V100\|GV100\|Tesla" | head -1 | awk '{print $1}')
if [ -n "$V100_BUS" ]; then
    echo "V100 found at bus: $V100_BUS"
    echo ""
    lspci -vvv -s "$V100_BUS" 2>/dev/null | grep -A 3 "Region"
    echo ""
    
    # Check for <ignored> which means allocation failed
    if lspci -v -s "$V100_BUS" 2>/dev/null | grep -q "<ignored>"; then
        echo "WARNING: Memory regions show <ignored> - allocation failed!"
        echo "The DSDT patch may not be working correctly."
    else
        echo "Memory regions appear to be allocated."
    fi
else
    echo "WARNING: V100 not detected by lspci"
    echo "Check if card is properly seated and powered"
fi
echo ""

echo "[6/8] Checking kernel PCI messages..."
dmesg | grep -i "pci\|bar" | grep -i "v100\|tesla\|nvidia" | tail -10
echo ""

echo "[7/8] Checking NVIDIA driver status..."
if lsmod | grep -q nvidia; then
    echo "NVIDIA driver is loaded"
    lsmod | grep nvidia
else
    echo "NVIDIA driver not loaded"
    echo ""
    echo "To install NVIDIA datacenter drivers:"
    echo "  apt install nvidia-driver"
    echo "  # OR download from NVIDIA directly"
fi
echo ""

echo "[8/8] Testing nvidia-smi..."
if command -v nvidia-smi &> /dev/null; then
    nvidia-smi
else
    echo "nvidia-smi not found - driver not installed"
fi

echo ""
echo "=============================================="
echo "Verification Complete"
echo "=============================================="
echo ""

# Summary
if lspci | grep -qi "V100\|GV100"; then
    if ! lspci -v | grep -qi "<ignored>"; then
        echo "STATUS: V100 detected with memory allocated"
        echo ""
        echo "If nvidia-smi works, you're done!"
        echo "If not, install drivers: apt install nvidia-driver"
    else
        echo "STATUS: V100 detected but memory NOT allocated"
        echo ""
        echo "DSDT patch may need adjustment. Check:"
        echo "  - /root/dsdt-patch/DSDT_modified.dsl for errors"
        echo "  - dmesg | grep -i pci for allocation errors"
    fi
else
    echo "STATUS: V100 not detected"
    echo ""
    echo "Possible causes:"
    echo "  - Card not properly seated"
    echo "  - Power connection issue"
    echo "  - BIOS still blocking during enumeration"
    echo ""
    echo "Try:"
    echo "  1. Reseat the V100"
    echo "  2. Check PCIe power cables"
    echo "  3. Try a different PCIe slot"
fi
