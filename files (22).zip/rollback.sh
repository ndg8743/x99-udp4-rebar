#!/bin/bash
# V100 DSDT Patch - Rollback
# Run this if things go wrong

echo "=============================================="
echo "V100 DSDT Patch - ROLLBACK"
echo "=============================================="
echo ""

read -p "This will remove all DSDT modifications. Continue? [y/N] " confirm
if [[ "$confirm" != "y" && "$confirm" != "Y" ]]; then
    echo "Cancelled."
    exit 0
fi

echo ""
echo "[1/4] Removing custom DSDT from /boot..."
if [ -f /boot/DSDT.aml ]; then
    rm /boot/DSDT.aml
    echo "Removed /boot/DSDT.aml"
else
    echo "Not found (already removed)"
fi

echo "[2/4] Removing GRUB ACPI loader..."
if [ -f /etc/grub.d/01_acpi ]; then
    rm /etc/grub.d/01_acpi
    echo "Removed /etc/grub.d/01_acpi"
else
    echo "Not found (already removed)"
fi

echo "[3/4] Restoring original GRUB config..."
if [ -f /etc/default/grub.backup ]; then
    cp /etc/default/grub.backup /etc/default/grub
    echo "Restored from backup"
else
    # Just remove the PCI parameters we added
    sed -i 's/ pci=realloc//g' /etc/default/grub
    sed -i 's/ pci=nocrs//g' /etc/default/grub
    sed -i 's/ pci=assign-busses//g' /etc/default/grub
    echo "Removed PCI parameters"
fi

echo "[4/4] Regenerating GRUB..."
update-grub

echo ""
echo "=============================================="
echo "Rollback Complete"
echo "=============================================="
echo ""
echo "System restored to original state."
echo "Reboot to apply changes."
echo ""
