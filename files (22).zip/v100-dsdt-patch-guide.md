# Tesla V100 on Gigabyte GA-X99-UD4P - DSDT Patching Guide

## System Configuration
| Component | Spec |
|-----------|------|
| Motherboard | Gigabyte GA-X99-UD4P Rev 1.0 |
| BIOS | F22 or F23c |
| CPU | Intel Xeon E5-2697A v4 (16C/32T, Broadwell-EP) |
| RAM | 128GB DDR4 2133MHz |
| Target GPU | NVIDIA Tesla V100 16GB |
| OS | Proxmox VE (Debian-based) |

## The Problem
- V100 won't POST (30-second boot loop, then shutdown)
- Above 4G Decoding not implemented in Gigabyte X99 consumer boards
- V100 requires 16GB BAR allocation above 4GB boundary

## The Solution
Since V100 is a "3D controller" (not VGA), BIOS might skip allocating it.
We'll use DSDT patching to expose 64-bit memory region and let Linux allocate the V100's BAR.

**Requirements:**
1. A cheap display GPU (GT 710 or similar) for video output during POST
2. V100 installed alongside the display GPU
3. Custom DSDT loaded via GRUB
4. Proper kernel parameters

---

## Phase 1: Preparation (Do this WITHOUT V100 installed)

### Step 1: Install Required Tools

```bash
# Update system
apt update && apt upgrade -y

# Install ACPI tools
apt install -y acpica-tools build-essential git

# Verify iasl is installed
iasl -v
```

### Step 2: Create Working Directory

```bash
mkdir -p /root/dsdt-patch
cd /root/dsdt-patch
```

### Step 3: Extract Current DSDT

```bash
# Extract DSDT from running system
cat /sys/firmware/acpi/tables/DSDT > DSDT.aml

# Backup original
cp DSDT.aml DSDT.aml.original

# Decompile to human-readable format
iasl -d DSDT.aml

# This creates DSDT.dsl
ls -la DSDT.dsl
```

### Step 4: Check Current PCI Resources

```bash
# Check current root bus resources
dmesg | grep "root bus resource"

# Check for Large Memory allocation
lspci -v | grep -A 20 "Memory at"
```

---

## Phase 2: DSDT Modification

### Step 5: Analyze DSDT Structure

```bash
# Search for existing QWordMemory entries
grep -n "QWordMemory" DSDT.dsl

# Search for DWordMemory entries (we'll add QWord after the last one)
grep -n "DWordMemory" DSDT.dsl

# Search for M1LN, M2LN variables
grep -n "M1LN\|M2LN\|M1MN\|M2MN" DSDT.dsl

# Search for TUUD (Top of Upper Usable DRAM)
grep -n "TUUD" DSDT.dsl
```

### Step 6: Create Modified DSDT

```bash
# Make a copy to modify
cp DSDT.dsl DSDT_modified.dsl
```

**Now edit DSDT_modified.dsl:**

Find all `DWordMemory` entries and after the LAST one, add:

```asl
QWordMemory (ResourceProducer, PosDecode, MinFixed, MaxFixed, Cacheable, ReadWrite,
    0x0000000000000000, // Granularity
    0x0000000000010000, // Range Minimum (placeholder)
    0x000000000001FFFF, // Range Maximum (placeholder)
    0x0000000000000000, // Translation Offset
    0x0000000000010000, // Length (placeholder)
    ,, _YAF, AddressRangeMemory, TypeStatic)
```

Then find the section with `M1LN` and add AFTER it:

```asl
CreateQWordField (BUF0, \_SB.PCI0._YAF._LEN, M2LN)  // _LEN: Length
CreateQWordField (BUF0, \_SB.PCI0._YAF._MIN, M2MN)  // _MIN: Minimum Base Address
CreateQWordField (BUF0, \_SB.PCI0._YAF._MAX, M2MX)  // _MAX: Maximum Base Address

// 46-bit addressing for X99/Haswell-E (64TB max)
M2MX = 0x3FFFFFFFFFFF - One
If ((TUUD >= 0x1000))
{
    M2MN = (TUUD << 0x14)
}
Else
{
    M2MN = 0x100000000
}

M2LN = ((M2MX - M2MN) + One)
```

**Note:** The `_YAF` identifier must match what you added in the QWordMemory section. If your DSDT already uses `_YAF`, use a different identifier like `_YAG`.

### Step 7: Compile Modified DSDT

```bash
cd /root/dsdt-patch

# Compile the modified DSDT
iasl -tc DSDT_modified.dsl

# Check for errors (warnings are OK)
# This creates DSDT_modified.aml

# Verify the file was created
ls -la DSDT_modified.aml
```

**Common compilation errors and fixes:**

| Error | Fix |
|-------|-----|
| `_HID suffix must be all hex digits` | Replace non-hex chars with F |
| `syntax error, unexpected '}'` | Remove preceding Arg lines |
| `Non-hex letters must be upper case` | Uppercase the letters |
| `Length is larger than Min/Max window` | Recalculate Length = Max - Min + 1 |

### Step 8: Install Modified DSDT for GRUB

```bash
# Copy to boot directory
cp DSDT_modified.aml /boot/DSDT.aml

# Verify
ls -la /boot/DSDT.aml
```

### Step 9: Configure GRUB to Load Custom DSDT

```bash
# Create GRUB configuration for DSDT
cat > /etc/grub.d/01_acpi << 'EOF'
#! /bin/sh
set -e

# Load custom DSDT
if [ -f /boot/DSDT.aml ]; then
    echo "Found custom DSDT: /boot/DSDT.aml"
    prepare_grub_to_access_device `${grub_probe} --target=device /boot/DSDT.aml`
    cat << ACPI_EOF
acpi /boot/DSDT.aml
ACPI_EOF
fi
EOF

# Make executable
chmod +x /etc/grub.d/01_acpi
```

### Step 10: Add Kernel Parameters

```bash
# Edit GRUB defaults
nano /etc/default/grub

# Find GRUB_CMDLINE_LINUX_DEFAULT and add these parameters:
# pci=realloc pci=nocrs pci=assign-busses
```

Example line:
```
GRUB_CMDLINE_LINUX_DEFAULT="quiet pci=realloc pci=nocrs pci=assign-busses"
```

### Step 11: Update GRUB

```bash
# Regenerate GRUB config
update-grub

# Verify DSDT is in the config
grep -i "acpi\|dsdt" /boot/grub/grub.cfg
```

---

## Phase 3: Hardware Installation

### Step 12: Shutdown and Install GPUs

```bash
# Shutdown cleanly
shutdown -h now
```

**Physical steps:**
1. Install GT 710 (or similar cheap display GPU) in a PCIe slot
2. Install Tesla V100 in a PCIe x16 slot
3. Connect monitor to GT 710 (not V100 - it has no display output)
4. Ensure adequate power connections

### Step 13: BIOS Settings (If you can access BIOS)

If the system POSTs with both GPUs:
- Set Primary Display to PCIe (for GT 710)
- Disable CSM if possible
- Leave Above 4G Decoding alone (it doesn't exist anyway)

---

## Phase 4: Boot and Verify

### Step 14: First Boot Attempt

Power on and watch for:
1. POST screen (via GT 710)
2. GRUB menu
3. Linux boot messages

### Step 15: Verify DSDT Loaded

```bash
# Check if custom DSDT was loaded
dmesg | grep -i "ACPI: DSDT"

# Check for 64-bit root bus resource
dmesg | grep "root bus resource"

# Look for resources ending in fffffffff or higher
```

### Step 16: Check V100 Detection

```bash
# List all NVIDIA devices
lspci | grep -i nvidia

# Check V100 specifically
lspci -vvv -s $(lspci | grep -i "V100\|GV100" | awk '{print $1}')

# Check memory regions
lspci -v | grep -A 10 "V100"
```

**What to look for:**
```
Region 0: Memory at XXXXXXXX (32-bit, non-prefetchable) [size=16M]
Region 1: Memory at XXXXXXXXXX (64-bit, prefetchable) [size=16G]  <-- This should show 16G, not <ignored>
Region 3: Memory at XXXXXXXXXX (64-bit, prefetchable) [size=32M]
```

### Step 17: Install NVIDIA Drivers

```bash
# Add non-free repository (if not already)
echo "deb http://deb.debian.org/debian $(lsb_release -cs) main contrib non-free" >> /etc/apt/sources.list
apt update

# Install NVIDIA datacenter drivers
apt install -y nvidia-driver nvidia-cuda-toolkit

# Or download directly from NVIDIA
# wget https://us.download.nvidia.com/tesla/xxx.xx/NVIDIA-Linux-x86_64-xxx.xx.run
# chmod +x NVIDIA-Linux-x86_64-xxx.xx.run
# ./NVIDIA-Linux-x86_64-xxx.xx.run
```

### Step 18: Verify V100 Working

```bash
# Check nvidia-smi
nvidia-smi

# Should show:
# Tesla V100-PCIE-16GB
# 16GB memory
# Temperature, power draw, etc.
```

---

## Troubleshooting

### If System Won't POST

1. Remove V100, boot with just GT 710
2. Remove DSDT override: `rm /boot/DSDT.aml && update-grub`
3. Try different PCIe slot for V100
4. Check power connections

### If V100 Shows `<ignored>` Memory

The DSDT patch didn't work correctly. Check:
```bash
dmesg | grep -i "pci\|bar\|resource"
```

### If nvidia-smi Fails

```bash
# Check driver loaded
lsmod | grep nvidia

# Check dmesg for errors
dmesg | grep -i nvidia

# Try reloading driver
modprobe -r nvidia
modprobe nvidia
```

### Kernel Parameters to Try

| Parameter | Purpose |
|-----------|---------|
| `pci=realloc` | Allow kernel to reallocate PCI resources |
| `pci=nocrs` | Ignore ACPI _CRS for PCI |
| `pci=assign-busses` | Reassign all PCI bus numbers |
| `pci=nommconf` | Disable MMCONFIG |
| `iommu=pt` | Passthrough IOMMU |
| `intel_iommu=on` | Enable Intel IOMMU |

---

## Required Software/Repos Summary

| Tool | Package/Source | Purpose |
|------|----------------|---------|
| iasl | `acpica-tools` | DSDT compilation |
| lspci | `pciutils` | PCI device info |
| nvidia-smi | NVIDIA drivers | GPU management |

---

## References

- DSDT Patching Guide: https://github.com/xCuri0/ReBarUEFI/wiki/DSDT-Patching
- Common Issues: https://github.com/xCuri0/ReBarUEFI/wiki/Common-issues-(and-fixes)
- Z97 + P40 Success (DSDT): https://winraid.level1techs.com/t/enable-above-4g-decoding-for-gigabyte-z97x-sli/90728
- GitHub Issue #303 (Your exact setup): https://github.com/xCuri0/ReBarUEFI/issues/303
